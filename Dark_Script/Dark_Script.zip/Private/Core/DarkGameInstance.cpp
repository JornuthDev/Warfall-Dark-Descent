﻿#include "Core/DarkGameInstance.h"


// ───────────────────────────────────────────────────────────────────────────────
// ─── Construction ──────────────────────────────────────────────────────────────
void UDarkGameInstance::Init()
{
	Super::Init();
}

void UDarkGameInstance::OnKicked_Implementation(const FString& KickReason)
{
}
