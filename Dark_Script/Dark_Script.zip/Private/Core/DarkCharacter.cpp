﻿#include "Core/DarkCharacter.h"

// ───────────────────────────────────────────────────────────────────────────────
// ─── Construction ──────────────────────────────────────────────────────────────
ADarkCharacter::ADarkCharacter()
{
	PrimaryActorTick.bCanEverTick = true;
}


